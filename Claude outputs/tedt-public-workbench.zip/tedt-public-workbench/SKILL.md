---
name: tedt-public-workbench
description: Public Workbench design system for tedt.org / preview.tedt.org: colour tokens (Paper and Night themes), type, spacing, ia-* component classes, imagery and WCAG rules. Use when building or restyling any tedt.org page, layout, include, section hub, tool card, footer, navbar or image, or when checking colours and contrast on the site.
---

# Public Workbench — tedt.org design system

The redesign of tedt.org (previewed at preview.tedt.org) as a quiet editorial library: one paper ground, Cal Sans headings over Inter, a blue backbone, a rust accent, and five shelves (Essays, Stories & Folklore, Games & Worlds, Tools, Learn) plus About. The target is **trusted craft**: an architect’s notebook and tool cabinet, not a SaaS dashboard.

## Read first

1. `references/brand-book.md`: voice, colour, type, layout, surfaces, iconography, and the WCAG table for brand orange and cyan. Always read it before writing UI.
2. `references/imagery.md`: when to use an image and when not, the size for each slot, alt text for the existing set, and the list of images still needed.
3. `references/components/<Name>.md`: the guidelines for the component you are building. `previews/<Name>-light.html` and `-dark.html` show working markup.
4. `references/marks-and-assets.md`: the “T” site mark, the Tschopp family mark, and the hero / shelf images in the repo.

## Files

| File | Use |
| --- | --- |
| `tokens.json` | Source of truth: colour tokens per theme (`light` = Paper, `dark` = Night), type styles, spacing, radii, sizes. Each entry has a `usage` note that says where it goes and its contrast. |
| `tokens.css` | The same tokens as CSS custom properties (`--ia-paper`, `--brand-orange`, `--space-5`, `--font-display` …). Dark values switch on `[data-bs-theme="dark"]` (the site) or `[data-theme="dark"]`. |
| `components.css` | Styles for the `ia-*` classes, scoped under `.library-site`. Mirrors `_sass/components/_information-architecture.scss`, plus the proposed accessibility changes listed in the brand book’s “Not synced” section. |
| `previews/` | One standalone HTML page per component and theme; open in a browser. |

## Rules that are easy to get wrong

- **Use tokens only.** Never hard-code a hex in a component. Both themes must work.
- **Colour roles:** links, selected states and outline buttons use `ia-link`. The primary button is `ia-primary` with `ia-on-primary`, at most one per view. `ia-accent` (rust) is for shelf numbers and “★ Featured” only. Text goes on `ia-paper` / `ia-surface` in `ia-ink` or `ia-muted`.
- **Brand orange and cyan:** use `brand-orange` / `brand-cyan`. They pass AA in both themes, and fills take `on-brand` labels. `brand-*-decor` are the raw production values, for illustration only, never for text, icons or controls.
- **Contrast floors:** text 4.5:1; large text, icons, control borders and focus rings 3:1. Every pair in `tokens.json` notes its ratio. Check any new pair in both themes before using it.
- **Surfaces:** hairline rules (`ia-rule`) instead of boxes and shadows. The only boxed elements are tool cards, search/filter panels and the about strip. No gradients except the category underline.
- **Type:** one `display-1` h1 per page. Headings are Cal Sans weight 400, tracking −0.025em. Body is Inter 18px / 1.65. Eyebrows are sentence case, never all caps.
- **Interaction:** links stay underlined. Focus is a 3px solid outline offset 4px. Targets are at least 44px and fields at least 48px. Honor `prefers-reduced-motion`.
- **Icons:** no icon font and no emoji. Use the Unicode glyphs ↗ ▾ ★ ↑ ☀ ◐ ☾ ☰ ✖, with decorative ones `aria-hidden="true"`.
- **Images:** one decorative image per page at most (the home hero or a shelf lead). Lists, rows, the footer and navigation stay text-only. Always set `width` / `height` to the file’s real pixels and write meaningful alt text.
- **Elsewhere on the Web:** keep `rel="me"` on every profile link.
- **Copy:** first person, plain and warm. Labels sound like tools (“Browse Essays”, “Live”, “Details”, “Code”), never like advertisements.

## Where things live in the repo

Edit menu labels in `_data/site_navigation.yml`, shelf content in `_data/site_sections.yml`, tool groups in `_data/tool_groups.yml`, and shared styles in `_sass/components/_information-architecture.scss`. Navbar, footer and preview banner markup are in `_includes/layout/`. Never edit `_site/`.
