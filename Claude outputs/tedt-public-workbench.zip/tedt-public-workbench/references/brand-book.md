Public Workbench is the system for **preview.tedt.org**: Ted Tschopp’s site rebuilt as a personal publication with a working lab attached. It has one paper reading surface, one display face, a blue backbone and a rust accent, and five shelves instead of nineteen categories. The emotional target is **trusted craft**. It should feel like an architect’s notebook and tool cabinet, not a SaaS dashboard, a startup landing page or a theme demo.

## What “modern and more usable” means here

| tedt.org (current) | Public Workbench (preview) |
| --- | --- |
| A carousel of 19 categories, each with its own decorative font and gradient underline | Five equal shelves (Essays, Stories & Folklore, Games & Worlds, Tools, Learn) plus About |
| Menu of individual apps and career pages | Six reader-oriented entrances, each a direct link plus a separate disclosure button |
| Many display faces (Sofia Sans Extra Condensed, script faces per category) | `display` (Cal Sans) for headings, `sans` (Inter) for everything else, `mono` (Fira Code) for numerals and code |
| Image-led cards and a video hero | Type-led rows divided by hairlines; one painted image per page at most |
| Recent posts repeated under every category | One recent-writing stream |
| Grey text on charcoal by default | Paper by day, slate by choice; every text pair ≥ 4.5:1 |
| Font Awesome and eleven stylesheets | Unicode glyphs (↗ ▾ ★ ☀/☾) and one component stylesheet |

To apply the system, wrap a page in `.library-site` and use the `ia-*` classes in `components/bundle.css`. They mirror `_sass/components/_information-architecture.scss`. Menu labels live in `_data/site_navigation.yml`, shelf content in `_data/site_sections.yml` and tool groups in `_data/tool_groups.yml`. Change those data files, not the templates.

## Content fundamentals

- **Voice:** first person, plain and warm, curious rather than authoritative. Examples: “I’m an enterprise architect, a storyteller, and a curious maker.” “A place for reflection, exploration, and work in progress.”
- **Plainspoken labels:** actions sound like tools, not advertisements. Use “Find Your Way In”, “Browse Essays”, “Live”, “Details”, “Code”, “Reset filter” and “Newest first”. No superlatives, no stats, no “Unlock…”.
- **Rhythm:** idea first (a strong title), explanation second (a one- or two-sentence deck), operational context third (date, status, type).
- **Casing:** headings, buttons and statuses in Title Case. Eyebrows, captions and descriptions in sentence case. Never all caps.
- **Metadata is content:** dates (“Sep 28, 2026”), status and content type stay visible. Never hide them behind hover.
- **No emoji.** The only glyphs are ↗ (goes somewhere), ▾ (opens), ★ (featured), ↑ (back to top) and ☀/☾ (theme).

## Visual foundations

**Color: Paper & Slate, Blue Backbone.** The ground is `ia-paper` and raised panels are `ia-surface`. Never use pure white or black as the reading field. Set headings and body in `ia-ink` and secondary copy in `ia-muted`. Every link, selected state and outline button uses `ia-link`, and the primary button uses `ia-primary` with `ia-on-primary`. Blue is the structural colour.

Use `ia-accent` (rust) only for shelf numbers and the “Featured” mark. `brand-orange` and `brand-cyan` are the production identity colours, adjusted so they pass WCAG AA in both themes (below). Divide with `ia-rule` and edge every form field with `ia-control`. The navbar is always `nav-bg` / `nav-ink`, in both themes. Status words use `signal-success`, `signal-warning`, `signal-danger` and `signal-info`.

**Brand orange and cyan (WCAG 2.2 AA).** tedt.org’s production orange #e86027 and cyan #00a9e0 pass on Night but fail on Paper: 3.2:1 and 2.5:1, against the 4.5:1 that text needs. So `brand-orange` and `brand-cyan` take a darker value of the same hue in light mode and the production value in dark mode. Every use is then safe:

| Use | `brand-orange` | `brand-cyan` | Minimum |
| --- | --- | --- | --- |
| Text and links on `ia-paper` / `ia-surface`, light | #bf4714 · 4.7:1 / 5.0:1 | #00779e · 4.7:1 / 5.0:1 | 4.5:1 |
| Text and links on `ia-paper` / `ia-surface`, dark | #e86027 · 5.2:1 / 4.7:1 | #00a9e0 · 6.6:1 / 6.0:1 | 4.5:1 |
| Icons, chart marks, focus or selected indicators | same values (all above 3:1) | same values (all above 3:1) | 3:1 |
| Fill with a label | `on-brand` white · 5.1:1 light; ink · 5.2:1 dark | `on-brand` white · 5.1:1 light; ink · 6.6:1 dark | 4.5:1 |

`brand-orange-decor` and `brand-cyan-decor` keep the exact production values. Use them only in illustration and large background art, where nothing has to be read or noticed. Don’t combine the two brand colours with each other, and don’t let colour alone carry meaning: pair it with a word or glyph. The category underline (`category-cyan` → `category-violet`) is darkened in light mode so it meets the 3:1 non-text minimum against Paper (3.0:1).

**Category accent.** The old site’s per-category gradients live on only as `.ia-category-title`: a 3px cyan→violet underline, exactly as wide as the title, on a category header inside a shelf page. Never use it on the home page, in the nav or as a band.

**Themes.** Light, System and Dark, from the SchemeSwitcher pill in the navbar (☀ ◐ ☾). Paper (light) is the first theme and Night (dark) is slate, not black. Both are complete, so never hard-code a hex in a component.

**Type.** Use `display-1` for the one h1 per page, `heading-2` for sections, and `heading-3` / `title-row` for items. All of these are `display`, weight 400, tracking −0.025em, leading 1.15. Body copy is `body` (18px / 1.65). Leads are `lead` in `ia-muted`, capped at `measure`, and kickers are `eyebrow`. Numerals and code are `mono`. Load all three families in one Google Fonts request with `display=swap`. Display type is punctuation, never louder than the writing.

**Layout.** Content sits in `.ia-container` (`container-max`, fluid gutters). Sections stack, each opened by a 1px `ia-rule` top border and `space-8` padding. Grids collapse as follows:

- Shelves: 5 → 3 → 1 columns.
- Highlights and tools: 3 → 1 columns.
- Groups: 1.2fr / 1fr → 1 column.

Breakpoints are 1200px and 768px.

**Spacing and radii.** Use the `space-1`…`space-10` steps. The workbench is mostly square (`radius-none`). Use `radius-sm` only on buttons, fields, tool cards, panels and images, and `radius-pill` only on status pills.

**Surfaces.** Borders only where they organize. Never build a box farm. No drop shadows, gradients (other than the category rule) or glass. The only boxed elements are tool cards, search/filter panels and the about strip. Hover sharpens: underline to 3px, a firmer border or a fill. Nothing lifts or animates.

**Imagery.** Painted, cinematic landscapes from `assets/Imagery`: one hero on the home page and one lead image under each shelf’s title. Lists, rows, the footer and navigation stay text-only. Images that show the thing itself (tool screenshots, maps, creatures, slides, an article’s own art) are content and follow the article. Use `radius-sm`, with no frame, overlay or shadow. The Imagery section has the full rules, the size for every slot, alt text for the existing set and the list of images still needed.

**Interaction and access:**

- Links are underlined.
- Focus is always visible: `focus-width` solid `ia-link` at a 4px offset (`nav-ink` on the navbar).
- Every nav item and dropdown row is at least `target-min` tall, and every field at least `field-min`.
- Anchored headings get `scroll-margin-top: 125px`.
- A skip link precedes the navbar.
- Honor `prefers-reduced-motion`.

## Iconography

There's no icon font. Use the Unicode glyphs under Content fundamentals, in the surrounding text colour, and give purely decorative ones `aria-hidden="true"`. There are two marks. The site mark is `assets/Logos/logo-Tschopp.svg`, the multicolour “T”, shown 48×48 in the navbar only. The **Tschopp family mark** (`assets/Logos/Family-*-Brush-Calligraphy-3.png`) is the personal signature: a single brush stroke in black ink on Paper and white ink on Night. It closes the footer’s name block, and may end a long essay or story as an end-mark. Use it once per page, never next to the “T” and never tinted. Everywhere else, set the name in `display` type: the footer wordmark is “Ted Tschopp” in `footer-name`.

## Not synced

- **Fonts:** Cal Sans, Inter, Fira Code and Titillium Web are Google-hosted (`css/shared-fonts.css`); no font files are copied. The repo's `fonts/` folder holds only the old site's decorative faces, which this system retires.
- **Values not in the source:** `brand-orange` / `brand-cyan` light values (#bf4714, #00779e), the light-mode category underline (#059cb6 → #9a79f9), `ia-control`, `ia-primary` (dark), `ia-on-primary` (dark), the `signal-*` pairs, the top-edge about-strip rule, and the SchemeSwitcher's pressed fill (`nav-ink` instead of `#00446f`) are proposed accessibility changes, not yet in `_information-architecture.scss`. Bootstrap's full palette (`$primary`… `$accent3`) is left out except where the preview uses it.
- **Components:** static renditions styled by `components/bundle.css`, hand-written from the `ia-*` rules and the `_includes/layout/` templates; there is no JS component library to build.
