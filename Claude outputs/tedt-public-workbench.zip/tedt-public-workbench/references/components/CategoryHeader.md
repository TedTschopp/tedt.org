# CategoryHeader
The opener for a category inside a shelf page (e.g. Swiss Folklore inside Stories & Folklore): eyebrow naming the shelf, title, the cyan→violet underline, a one-or-two-sentence deck, and an optional lead image.

**Consumer provides:** shelf name, category title, deck, optional lead image with alt text.

- This is the one place the old site's category identity survives: a 3px underline from `category-cyan` to `category-violet` that runs exactly the width of the title: put `.ia-category-title` on the heading (inline-block, the gradient as a bottom background). Keep it restrained — never a full-width band, never on the home page or in the nav.
- Title `heading-2`; deck `lead` / `ia-muted`; lead image from the shelf set (3:1 source, shown 4:1 on desktop and 2:1 on phones with the focal point from the Imagery section), `radius-sm`.
- Rhythm: idea first (title), explanation second (deck), operational context third (a metadata row or jump links).
