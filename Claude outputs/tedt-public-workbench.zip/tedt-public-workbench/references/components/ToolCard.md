# ToolCard
The one boxed element on the site: a browser tool with its category, name, one-line purpose, meta and actions.

**Consumer provides:** category eyebrow, name + href, description, meta (status pill, last updated), and the action row — `Live ↗`, `Details`, `Code` — plainspoken, never promotional.

- Ground `ia-surface`, border `ia-rule`, radius `radius-sm`, padding `space-5`; 3 across, 1 on phones.
- Mark a featured tool with "★ Featured" in `ia-accent` after the title (`.ia-featured`).
- Cards are for tools (and prompts/presentations on their own shelves). Essays stay as rows: don’t flatten different kinds of work into one card treatment.
- Status and the updated date are always visible — they help a reader decide what to trust.
