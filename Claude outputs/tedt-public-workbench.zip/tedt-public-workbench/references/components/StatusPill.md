# StatusPill
A small rounded label that states where a piece of work stands, set beside a title or in a tool's meta row.

**Consumer provides:** the status word from the site's vocabulary (the `status:` field of `_tools/*.md`). The word is the meaning; colour only reinforces it.

| Status | Class | Text colour |
| --- | --- | --- |
| Active | `.ia-status--active` | `signal-success` |
| Maintained | `.ia-status--maintained` | `signal-success` |
| Beta | `.ia-status--beta` | `signal-warning` |
| Prototype | `.ia-status--prototype` | `signal-warning` |
| Under Development | `.ia-status--development` | `signal-warning` |
| Archived | `.ia-status--archived` | `ia-muted` |

- Ground `ia-surface`, border `ia-rule`, radius `radius-pill`, `status` text style, Title Case (not the all-caps of the old tool cards).
- One pill per title, never a row of tags. Topics belong to the shelf, not to pills.
- Status is product truth: never mark something Active that isn't maintained.
