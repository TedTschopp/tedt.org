# Elsewhere
“Elsewhere on the Web” — every place to find Ted online, rebuilt from the old footer’s 35-link, six-category icon wall into two tiers: six places where he is most active, shown with their handles, and everything else behind one “Everywhere else” disclosure.

**Consumer provides:** the links from `_config.yml` `links:` (Name, URL, Username, Category). Add one field per entry — `Priority: primary` for the six top-tier places — and an optional `Handle` when the display handle differs from `Username` (e.g. `@TedT@twit.social`). Drop `Icon-Class` and `Color`; they are no longer used.

**Top tier (`.ia-elsewhere-list`).** Mastodon, Bluesky, LinkedIn, GitHub, Hugging Face, Email. Each is one full-width row link: platform name (Inter 600), handle in `mono` / `ia-muted`, a one-word context (“Fediverse”, “Work”, “Code”), and ↗. Rows are ruled with `ia-rule`, at least `target-min` tall, 3 → 2 → 1 columns. Handles are the point — people search for a handle, not a logo.

**Everyone else (`.ia-elsewhere-more`).** A native `<details>` closed by default, its summary showing the count. Inside, reader-facing groups replace the old Categories:
- **Social** — Threads, Facebook, Instagram, Messenger, X (Twitter), Reddit, Snapchat
- **Writing & Reading** — Medium, Goodreads, Tumblr, Quora, Pinterest
- **Video, Music & Images** — YouTube, Twitch, Vimeo, SoundCloud, Suno, Midjourney
- **Code & Identity** — Dev.to, Keybase, IndieWeb, Bridgy Fed
- **Games** — Steam, Xbox, GOG
- **Around Town** — Meetup, Foursquare

Plain text links, 0.9rem, no icons. “Website” is dropped — the reader is already on it.

**Support.** Buy Me a Coffee moves out of the link wall into one quiet closing line.

**Rules**
- Every link keeps `rel="me"` (and the h-card classes when inside the footer): it is how Mastodon verification and IndieWeb identity work. Never remove it while modernising.
- No brand colours, no icon font, no emoji. Platform names in plain text are faster to scan, readable in both themes, and never fail contrast (the old Snapchat yellow, Goodreads cream and Dev.to white icons were invisible on Paper).
- Use the platform’s current name (“X (Twitter)”, “Bluesky”, “GOG”, “Xbox”), never `<wbr>`-split names.
- Place it on the About page and as a band above the footer’s bottom row; never in the navbar.
