# WritingRow
One line of the "New Writing" list: date, linked title, one-sentence dek, and a ↗ cue.

**Consumer provides:** a `<time datetime>` date, title + href, dek (one sentence, the post's description).

- Grid 7.5rem / 1fr / 1rem, gap `space-5`, bottom rule `ia-rule`. Stacks on phones and drops the ↗.
- Date in `meta` ("Sep 28, 2026"); title in `title-row`; dek in `body-sm` / `ia-muted`.
- No thumbnails or category badges — the list is for scanning.
