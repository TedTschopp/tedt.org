# Navbar
The fixed night bar at the top of every page: brand mark, the five shelves plus About, the Light / System / Dark scheme switcher and the Show / Hide table-of-contents toggle. Markup: `_includes/layout/top-nav-bar.html`, items from `_data/site_navigation.yml`; the Preview banner is `_includes/layout/preview-banner.html` (preview builds only).

**Consumer provides:** the brand mark (`assets/Logos/logo-Tschopp.svg`, 48×48, `object-fit: contain`, `alt="Ted Tschopp home"`), the nav items in order — Essays, Stories & Folklore, Games & Worlds, Tools, Learn, About ▾ — and the current item marked `.active` with `aria-current="page"`.

- Ground `nav-bg`, links `nav-ink`, height `nav-height`, every item `target-min` tall at 15px. Night in both themes.
- Active and hover: underline offset .4em — no colour pills, no icons.
- Two segmented pill controls end the bar (see SchemeSwitcher): Color scheme (Light ☀ · System ◐ · Dark ☾) and, on article pages from 992px up, Table of contents (Show ☰ · Hide ✖).
- Dropdowns use a separate disclosure `<button>` (`.ia-nav-disclosure`, `aria-expanded`) so the label stays a real link.
- Under 1200px the items collapse into a full-width panel on `nav-bg`; each row stays 44px tall.
- Never more than six top-level items; new sections go inside a shelf.
