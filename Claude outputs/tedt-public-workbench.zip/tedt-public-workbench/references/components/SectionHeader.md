# SectionHeader
The top of a shelf page: breadcrumb, h1, lead, and jump links to the groups below.

**Consumer provides:** breadcrumb trail, title, lead, and the list of group anchors.

- Breadcrumb 0.85rem `ia-muted`, separated by "/". h1 `display-1`; lead `lead`.
- Jump links 0.87rem `ia-link`, gap .65rem 1.25rem, each with ≥.35rem block padding for touch.
- Anchored targets carry `scroll-margin-top: 125px` so the fixed nav never covers them.
