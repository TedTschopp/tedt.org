# Button
Two buttons and a text link carry every action on the workbench: `.btn-primary` for the one main action in a view, `.btn-outline-primary` for a secondary action, and `.ia-text-link` with a trailing ↗ for "go somewhere".

**Consumer provides:** an `<a>` (navigation) or `<button>` (in-page action), the label, and for text links the ↗ glyph inside the link.

- One `btn-primary` per view. Fill `ia-primary`, label `ia-on-primary`, radius `radius-sm`, padding .75rem 1.25rem, min height `target-min`.
- Outline: border and label `ia-link`; on hover fill `ia-link`, label `ia-paper`.
- Labels are Title Case verbs or destinations: "Find Your Way In", "About Ted", "Browse Essays".
- Text links are `ia-link`, weight 600, underlined; hover thickens the underline to 3px.
- Don't use `ia-accent` (rust) or Bootstrap's call-to-action orange for buttons.
