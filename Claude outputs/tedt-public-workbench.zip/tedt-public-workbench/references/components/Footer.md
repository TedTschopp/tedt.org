# Footer
The closing map: the name as a link to About, a two-line description and the views disclaimer, then “Explore” (the six sections) and “Keep in Touch”, then copyright and Back to Home.

**Consumer provides:** nothing per page — markup is `_includes/layout/library-footer.html`, the Explore list is generated from `_data/site_navigation.yml`.

- Grid 2fr / 1fr / 1fr (two columns on phones, the name block full width), top rule `ia-rule`, padding `space-8` / `space-5`.
- Name in `footer-name` (`display`), linked to /about-ted/. Description `body-sm` in `ia-muted`; disclaimer `small`.
- The Tschopp family mark closes the name block (`.ia-familymark`, 3.5rem tall): the black brush version on Paper, the white one on Night — ship both `<img>`s and let the theme pick. It replaces the old footer’s `footer-housemark`.
- Column headings are h2 at 1.1rem `display`, each column a `<nav>` with its own `aria-label`. Lists 0.9rem.
- Bottom row 0.8rem `ia-muted` over a hairline.
- Elsewhere on the Web (the Elsewhere component) sits as its own band directly above the footer grid, replacing the old footer’s icon wall of 35 links.
