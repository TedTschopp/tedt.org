# SearchForm
The search and tool-filter panel: a query field, a scope select, and a submit button on one raised strip.

**Consumer provides:** a `<form role="search">`, labelled input and select (visible `<label>`s, never placeholder-only), and the submit button.

- Panel `ia-surface`, border `ia-rule`, radius `radius-sm`, padding `space-5`; grid 2fr / 1fr / auto, one column on phones.
- Fields: min height `field-min`, border `ia-control` (3:1 against the panel), focus ring 3px `ia-link` offset 4px.
- Labels 0.9rem weight 600 in `ia-ink`.
