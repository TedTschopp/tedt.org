# DestinationGroup
A group on a shelf page: intro on the left, a ruled list of destinations on the right.

**Consumer provides:** group heading + intro sentence, and a list of destinations (label, href, optional trailing meta such as a count or ↗).

- Grid 1.2fr / 1fr, gap `space-8`, top rule `ia-rule`, padding `space-7`.
- Each destination is a full-width row link (.75rem padding) divided by `ia-rule`; underline on hover.
- This is where the old site's categories live now: a list a reader can scan, not a carousel.
