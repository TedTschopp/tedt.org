# Hero
The home page opener: eyebrow, a three-line display headline, a lead paragraph, one primary action and one text link, beside a single landscape photograph with a caption.

**Consumer provides:** the eyebrow, h1, lead, two actions and a photograph with alt text and caption.

- Grid 1.25fr / 1fr, gap `space-9`, padding `space-10`; one column under 768px.
- h1 in `display-1`; lead in `lead` / `ia-muted`, max `measure`.
- The photograph is `assets/Imagery/hero-lake.webp` — a painted landscape (warm sky, figure from behind, still lake). Height `hero-photo-h`, radius `radius-sm`, no frame or shadow. Ship a 4:3 file (853 × 640 centre crop of `hero-lake`, or 1200 × 900) whose `width`/`height` attributes match it. Caption in 0.82rem `ia-muted`.
- Voice: first person, plain, warm — "I’m an enterprise architect, a storyteller, and a curious maker."
