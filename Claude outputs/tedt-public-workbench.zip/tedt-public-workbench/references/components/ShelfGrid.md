# ShelfGrid
The five shelves — the site's whole map in one row. Each shelf is a mono number, a linked name, one sentence, and three doorways.

**Consumer provides:** for each shelf: number (01–05), name, href, one-sentence description, and three sub-links.

- The shelves are fixed: 01 Essays · 02 Stories & Folklore · 03 Games & Worlds · 04 Tools · 05 Learn. Every post belongs on exactly one shelf; old categories (AI, Leadership, Shadowrun, Maps…) become doorways inside a shelf, never new shelves.
- Number in `shelf-number` / `ia-accent`; name in `heading-3`; description `ia-muted`.
- Shelves are divided by `ia-rule` hairlines, not boxed. 5 columns → 3 under 1200px → 1 on phones (rules turn horizontal).
