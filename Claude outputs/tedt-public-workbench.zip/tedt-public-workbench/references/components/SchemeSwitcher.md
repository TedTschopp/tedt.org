# SchemeSwitcher
A segmented pill of toggle buttons in the navbar: the Color scheme control (Light · System · Dark) on every page, and the Table of contents control (Show · Hide) on article pages at 992px and wider.

**Consumer provides:** a `role="group"` wrapper with an `aria-label` ("Color scheme", "Table of contents"), and one `<button type="button">` per option with `title`, `aria-label` and `aria-pressed` — exactly one pressed. Markup: `#colorSchemeToggle` and `#tocVisibilityToggle` in `_includes/layout/top-nav-bar.html`; behaviour in the site's scheme and TOC scripts (`data-color-scheme="light|auto|dark"`, `data-toc-visibility="show|hide"`).

- Pill outline 2px `switcher-border`, 2px inner padding and gap, buttons `target-min` square in the icon variant (`.scheme-switcher--icons`), `padding: 0 .65rem` in the text variant.
- Pressed: fill `nav-ink`, glyph `nav-bg` (16.6:1). The repo fills the pressed button with `#00446f`, which sits at 1.75:1 against the navbar — too faint to see which option is on.
- Glyphs: ☀ Light, ◐ System, ☾ Dark; ☰ Show, ✖ Hide. The repo's System glyph is the 💻 emoji; ◐ keeps the set monochrome. Glyphs are `aria-hidden`; the button's `aria-label` carries the name.
- The TOC control is hidden on section and home pages (`[data-toc-visibility-container]` is suppressed inside `.library-site`).
