# AboutStrip
The closing "person behind the work" band: eyebrow, h2, two sentences, and an About button.

**Consumer provides:** eyebrow, heading, short bio, button label + href.

- Ground `ia-surface`, padding `space-6`, a 4px `ia-primary` rule along the TOP edge (not the left — a coloured left border reads as a generic card).
- Copy max 43rem in `ia-muted`. Button `.btn-outline-primary`.
