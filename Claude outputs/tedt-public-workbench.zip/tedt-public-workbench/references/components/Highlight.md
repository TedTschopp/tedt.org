# Highlight
A curated entry point: shelf eyebrow, linked title, optional status pill, one sentence. Used three across in "A Few Places to Start".

**Consumer provides:** eyebrow (the shelf name), title + href, description, optional `StatusPill`.

- No box, no image, no shadow — whitespace and type do the work. Padding `space-4` vertical, column gap `space-7`.
- One highlight per shelf so every interest gets "equal room to explore".
