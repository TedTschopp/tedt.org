# Marks and image assets

Files live in the tedt.org repo: `img/home/logo-Tschopp.svg`, `img/home/logo-Tschopp.png`, `img/familymark/Family-Black-Brush-Calligraphy-3.png`, `img/familymark/Family-White-Brush-Calligraphy-3.png`, and `img/categories/home-hero-images/hero-*.webp`.

## Logos

Two marks, two jobs.

**The “T” site mark** — a multicolour, painterly letter T. `logo-Tschopp.svg` is the master (612×1024 viewBox, full colour, reads on both `nav-bg` and `ia-paper`); `logo-Tschopp.png` is the 256×256 raster for social cards and app icons. Show it 48×48 with `object-fit: contain` in the navbar, linked home, `alt="Ted Tschopp home"`. Never recolour, outline or redraw it; never put it on `ia-primary`.

**The Tschopp family mark** — a single-ink brush-calligraphy housemark (an upright stroke crossed twice, with a small ring). `Family-Black-Brush-Calligraphy-3.png` is black ink for Paper (`ia-paper`, `ia-surface`, `banner-bg`); `Family-White-Brush-Calligraphy-3.png` is white ink for Night and `nav-bg`. Both are 1254×1254 transparent PNGs with generous margin — crop to the stroke or size by height. Use it as a personal signature, not a logo: once per page, closing the footer’s name block (3.5rem tall), or at the end of a long essay or folklore story as an end-mark (1.5–2rem). Never in the navbar, never beside the “T” mark, never tinted, never on a photograph. Always `alt="Tschopp family mark"` (or empty `alt` when a labelled wrapper names it).

## Imagery

Painted, cinematic landscapes at 1904×640, from `img/categories/home-hero-images/`. `hero-lake.webp` is the home hero (cropped to `hero-photo-h`, captioned “A place for reflection, exploration, and work in progress.”). Each shelf has one lead image: Essays `hero-hardware.webp`, Stories & Folklore `hero-village.webp`, Games & Worlds `hero-dice.webp`, Tools `hero-library.webp`, Learn `hero-data-center.webp` (as set in `_data/site_navigation.yml`). One image per page at most, `radius-sm`, no frame, overlay or shadow; always meaningful `alt` text.
