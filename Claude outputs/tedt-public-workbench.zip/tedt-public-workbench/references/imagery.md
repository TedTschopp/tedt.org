# Imagery

Images on the workbench do one of two jobs. They set the mood of a place (the home page or a shelf), or they show the thing itself (a tool's interface, a creature, a map, a slide). Anything that does neither is left out. That restraint is the main difference from tedt.org, whose home page carries 91 images and a video.

## When to use an image

- **Home hero.** One painted landscape, once (`hero-lake`).
- **Shelf lead.** One wide image under each shelf’s title (Essays, Stories & Folklore, Games & Worlds, Tools, Learn, About). It tells a reader which room they have walked into.
- **The article’s own image.** An essay, story or slide deck may open with its lead image (`image:` in front matter, 16:9). Illustrations inside the text are content, not chrome, and follow the article.
- **Showing the actual thing.** Tool screenshots, maps, bestiary creatures, slide previews and diagrams. Here the picture is the information.
- **Social cards.** Every page needs an Open Graph image, even when the page itself shows none.
- **Marks.** The “T” in the navbar, and the family mark closing the footer. They are identity, not decoration.

## When not to use an image

- **Lists made for scanning:** shelf grids, writing rows, destination lists, jump links, footer, Elsewhere on the Web. Titles and one-line descriptions are faster to scan without images.
- **Highlights**, except Games and Stories, where a creature or a place is the point.
- **Stock-style filler:** handshakes, lightbulbs, generic “AI brain” art, or a picture that only repeats the headline.
- **Text in images.** Headings, quotes and buttons stay live text. Social cards are the one exception.
- **Images as navigation icons**, emoji, or per-category logos. Use words and the Unicode glyphs instead.
- **Background images behind text**, gradients over photos, or captions laid over pictures. They fail contrast in one theme or the other.
- **More than one decorative image per page.** If a page already has a hero or shelf lead, everything below it is type.

## How to use one

- **Size and format:** WebP, sRGB, under 200 KB for leads and heroes and under 120 KB for thumbnails. Always set `width` and `height` to the file’s real pixels.
- **Loading:** use `loading="lazy"` below the fold. Use `fetchpriority="high"` only on the hero or shelf lead.
- **Cropping:** crop with CSS (`object-fit: cover` plus an `object-position` focal point). Never stretch.
- **Corners and edges:** use `radius-sm`, with no border, shadow, filter or overlay.
- **Style:** painted and cinematic, matching the existing set: one subject or one place, a single light source, and a slightly muted teal / amber palette that sits on both Paper and Night. No photo-real people other than Ted.
- **Alt text:** describe what is in the picture, in one sentence, without “image of”. Use `alt=""` only when a caption beside it says the same thing.
- **Credits:** AI-generated or third-party art keeps `image-artist` / `image-credits` in front matter, as posts already do.

## Sizes by slot

| Slot | Aspect | Source file | Shown at (desktop · phone) | Focal point |
| --- | --- | --- | --- | --- |
| Home hero | 4:3 | 1200 × 900 (min 853 × 640) | ≈ 500 × 390 · 358 × 220 | subject centred |
| Shelf lead | 3:1 source, shown 4:1 desktop, 2:1 phone | 2400 × 800 (min 1904 × 640) | 1184 × 296 · 358 × 179 | per image (below) |
| Article lead | 16:9 | 1672 × 941 (the posts’ current standard) | up to 1184 wide | — |
| Tool thumbnail | 16:9 | 1280 × 720 | ≈ 333 × 187 · 326 × 183 (inside card padding) | the tool’s main panel |
| Highlight thumbnail (Games, Stories) | 4:3 | 800 × 600 | ≈ 368 × 276 · 358 × 269 | subject centred |
| About portrait | 1:1 | 800 × 800 | 240 × 240 · 160 × 160 | face on the upper third |
| Social card (Open Graph) | 1.91:1 | 1200 × 630 | — | keep text inside the centre 1000 × 500 |
| Family mark | as supplied | 1254 × 1254 PNG, transparent | 3.5rem tall in the footer | — |
| Navbar mark | 1:1 | SVG | 48 × 48 | — |

## Image inventory

**Have, ready to use.** These already exist in `img/categories/home-hero-images/` at 1904 × 640. The alt text below is the recommended copy.

| File | Slot | Alt text | `object-position` |
| --- | --- | --- | --- |
| `hero-lake.webp` | Home hero (needs the 4:3 crop below) | A figure seen from behind sits at the edge of a still mountain lake at sunset, cabins glowing among the pines. | 50% 60% |
| `hero-hardware.webp` | Essays shelf lead | A hand presses a component into a dark circuit board traced with glowing cyan lines. | 30% 50% |
| `hero-village.webp` | Stories & Folklore shelf lead | A mist-filled valley at dusk, with an old Swiss village and church tower beneath forested hills. | 60% 70% |
| `hero-dice.webp` | Games & Worlds shelf lead | A hand-drawn map glowing blue on a wooden table, with polyhedral dice, a jar of dice and a closed notebook. | 45% 55% |
| `hero-library.webp` | Tools shelf lead | A vaulted library hall lined with bookshelves, ending in a tall stained-glass doorway. | 50% 55% |
| `hero-data-center.webp` | Learn shelf lead | A person seen from behind faces a wall of screens showing glowing circuit diagrams. | 25% 45% |
| `Family-Black/White-Brush-Calligraphy-3.png` | Footer family mark | Tschopp family mark | — |
| `logo-Tschopp.svg` | Navbar | Ted Tschopp home | — |

**Needed.**

| # | Image | Size | Description / brief | Priority |
| --- | --- | --- | --- | --- |
| 1 | Home hero, 4:3 crop | 853 × 640 now (centre crop of `hero-lake`); 1200 × 900 if regenerated | Same scene, cropped around the seated figure and the sun’s reflection. The page already declares `width="960" height="720"` (4:3) while the file is 3:1, so the crop also fixes the layout shift. | Now |
| 2 | About shelf lead | 2400 × 800 | Painted, same style as the set: a writing desk by a window at dusk, with an open notebook, a few dice, a laptop and a folklore book — “one person’s public workbench”. Teal / amber light, no person. | Now |
| 3 | About portrait | 800 × 800 | Head-and-shoulders photograph of Ted on a plain, warm neutral background. The existing `img/home/Ted-Tschopp-Enterprise-Architect-v4.webp` (1500 × 1000) is a candidate if re-cropped to square. | Now |
| 4 | Social card: site default | 1200 × 630 | `hero-lake` crop on the right two-thirds; a left `ia-paper` band with “Ted Tschopp” in Cal Sans and “Technology, Stories, and Imagined Worlds” in Inter, both in `ia-ink`. Replaces `Site-Logo.webp`, which is a 1024 × 1024 square that platforms crop. | Now |
| 5–10 | Social cards: Essays, Stories & Folklore, Games & Worlds, Tools, Learn, About | 1200 × 630 each | The same template with that shelf’s lead image and its name. | Now |
| 11 | Plotto tool thumbnail | 1280 × 720 | Screenshot of the plot generator showing one generated plot. No thumbnail exists yet. | Soon |
| 12 | Social Bot Check tool thumbnail | 1280 × 720 | Screenshot of the checker with one result filled in. No thumbnail exists yet. | Soon |
| 13 | Procedural Text Generator thumbnail | 1280 × 720 | Screenshot of the generator’s output. Front matter points to `/img/404/404-1.webp`, which doesn’t exist. | Soon |
| 14 | Tool thumbnails re-cropped to 16:9 | 1280 × 720 each | Re-crop to the main working panel: AI Chat Window (1425 × 2036), Gradient Card (1201 × 1206), Markdown Frontmatter (1425 × 1234), Morph (1585 × 1184), OCR Workspace (1440 × 1559), QR Builder (1500 × 500). Resize SLOCCount (4538 × 2553, about 3.5× larger than needed). Export Fractal from its SVG to WebP. | Soon |
| 15 | Highlight: The Swiss Folklore Collection | 800 × 600 | 4:3 crop of `img/home/Folklore.webp` (1904 × 640) around its central subject. | Optional |
| 16 | Highlight: Creatures for Your Next Session | 800 × 600 | One Gamma World creature from the bestiary art, alone on a plain painted ground. | Optional |
| 17 | Shelf leads at full resolution | 2400 × 800 each | Re-export the five shelf leads at 2400 wide if the originals allow. 1904 is fine at 1×, slightly soft on Retina. | Later |
